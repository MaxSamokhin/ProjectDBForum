create function add_forum_users() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO forum_users (user_id, forum_id) VALUES (NEW.user_id, NEW.forum_id);
    RETURN NEW;
  END;
$$;
