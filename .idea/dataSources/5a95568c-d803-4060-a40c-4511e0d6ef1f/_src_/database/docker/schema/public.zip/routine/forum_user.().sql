create function forum_user() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO Forum_User (user_id, forum_id) VALUES (NEW.author_id, NEW.forum_id);
  RETURN NULL;
END;
$$;
