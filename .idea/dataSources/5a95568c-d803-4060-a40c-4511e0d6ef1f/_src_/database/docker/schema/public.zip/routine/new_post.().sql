create function new_post() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO forum_f_u (forum_id, user_id) VALUES (NEW.forum, NEW.author);
    RETURN NEW;
    END
$$;
