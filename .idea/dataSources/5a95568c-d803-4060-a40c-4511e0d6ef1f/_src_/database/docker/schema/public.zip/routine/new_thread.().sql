create function new_thread() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO forum_stat (forum_id, threads) VALUES (NEW.forum, 1) ON CONFLICT (forum_id) DO UPDATE SET threads = forum_stat.threads + 1;
    INSERT INTO forum_f_u (forum_id, user_id) VALUES (NEW.forum, NEW.author);
    RETURN NEW;
    END
$$;
