create function new_vote() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE forum_thread SET votes = votes + NEW.voice WHERE NEW.thread=forum_thread.id;
    RETURN NEW;
    END
$$;
