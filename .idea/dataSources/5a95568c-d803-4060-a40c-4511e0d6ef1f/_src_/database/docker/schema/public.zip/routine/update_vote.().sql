create function update_vote() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE forum_thread SET votes = votes - OLD.voice + NEW.voice WHERE NEW.thread=forum_thread.id;
    RETURN NEW;
    END
$$;
