create function users_forum_add() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO users_forum (user_id, forum_id) VALUES (NEW.user_id, NEW.forum_id);
    RETURN NEW;
  END;
$$;
